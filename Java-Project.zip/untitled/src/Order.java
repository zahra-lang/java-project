import java.util.List;

public class Order {
    Customer customer;
    List<FoodItem> items;
    String address;
    boolean isOnline;

    public Order(Customer customer, List<FoodItem> items, boolean isOnline, String address) {
        this.customer = customer;
        this.items = items;
        this.isOnline = isOnline;
        this.address = address;

    }

    public double calculateTotal() {
        double sum = 0;
        for (FoodItem item : items) {
            sum += item.getPrice();
        }
        if (customer.hasSubscription() && "SUB10".equals(customer.getDiscountCode())) {
            return sum * 0.9;
        }
        return sum;
    }

    @Override
    public String toString() {
        return "Order by: " + customer.getUsername() + ", Total: " + calculateTotal();
    }

    public User getCustomer() {
        return customer;
    }
    public List<FoodItem> getItems() {
        return items;
    }
}

