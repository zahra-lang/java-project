import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.util.*;

public class FileHandler {
    private static final Gson gson = new Gson();

    public static void saveCustomers(List<Customer> customers, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            gson.toJson(customers, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Customer> loadCustomers(String filename) {
        try (FileReader reader = new FileReader(filename)) {
            Type listType = new TypeToken<List<Customer>>() {}.getType();
            return gson.fromJson(reader, listType);
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public static void saveMenu(List<FoodItem> menu, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            gson.toJson(menu, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<FoodItem> loadMenu(String filename) {
        try (FileReader reader = new FileReader(filename)) {
            Type listType = new TypeToken<List<FoodItem>>() {}.getType();
            return gson.fromJson(reader, listType);
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public static void saveEmployees(List<Employee> employees, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            gson.toJson(employees, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Employee> loadEmployees(String filename) {
        try (FileReader reader = new FileReader(filename)) {
            Type listType = new TypeToken<List<Employee>>() {}.getType();
            return gson.fromJson(reader, listType);
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public static void saveManagers(List<Manager> managers, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            gson.toJson(managers, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Manager> loadManagers(String filename) {
        try (FileReader reader = new FileReader(filename)) {
            Type listType = new TypeToken<List<Manager>>() {}.getType();
            return gson.fromJson(reader, listType);
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public static void saveOrders(List<Order> orders, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            gson.toJson(orders, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Order> loadOrders(String filename) {
        try (FileReader reader = new FileReader(filename)) {
            Type listType = new TypeToken<List<Order>>() {}.getType();
            return gson.fromJson(reader, listType);
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }
}
