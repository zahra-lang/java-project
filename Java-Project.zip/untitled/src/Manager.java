
import java.util.List;
import java.util.Scanner;

public class Manager extends User {

    public Manager(String username, String password) {
        super(username, password);
    }

    // متد برای تغییر قیمت غذا
    public void updateMenu(FoodItem food, double newPrice) {
        food.setPrice(newPrice);
    }

    // متد برای ویرایش منو توسط مدیر
    public void modifyMenu(List<FoodItem> menu, Scanner scanner) {
      //  manager.modifyMenu(menu, scanner);
        FileHandler.saveMenu(menu, "menu.json");

        print("لطفاً شماره غذایی که می‌خواهید ویرایش کنید را وارد کنید:");
        String foodid = scanner.nextLine();

        for (FoodItem food : menu) {

            if (food.getId().equalsIgnoreCase(foodid)) {
                print("قیمت جدید را وارد کنید:");
                double newPrice = scanner.nextDouble();
                scanner.nextLine(); // مصرف newline اضافی پس از خواندن عدد
                food.setPrice(newPrice);
                println("قیمت غذا به روز شد.");
                line1();
                return;
            }
        }
        println("غذا یافت نشد.");
    }

    // افزودن مشتری
    public void addCustomer(Customer customer, List<Customer> customerList) {
        customerList.add(customer);
    }

    // افزودن کارمند (در صورت نیاز توسعه آینده)
    public void addEmployee(Employee employee, List<Employee> employeeList) {
        employeeList.add(employee);
    }

    // چاپ سفارش‌ها
    public void printOrders(List<Order> orders) {

            boolean hasOrders = false;
            for (Order order : orders) {
                User customer = order.getCustomer();
                if (order.getCustomer().getUsername().equals(customer.getUsername())) {
                    println("نام مشتری: " + customer.getUsername());
                    println("آیتم‌های سفارش: " + order.getItems());
                   println("مبلغ کل سفارش:"+order.calculateTotal());
                    hasOrders = true;
                }
            }
            if (!hasOrders) {
                println("هیچ سفارشی ثبت نشده است.");
            }
        }
    public static void println(String text) {
        int width = 150;
        System.out.println(String.format("%" + (width / 2 + text.length() / 2) + "s", text));

    }
    public static void print(String text) {
        int width = 150;
        System.out.print(String.format("%" + (width / 2 + text.length() / 2) + "s", text));

    }
    public static void line1(){
        String text="                  --------------------------------------------------------------------------------------------------------------------";
        System.out.println(text);
    }
    }



