import java.util.List;

public class Employee extends User {
    public Employee(String username, String password) {
        super(username, password);
    }

    public void addOrder(Order order, List<Order> orderList) {
        orderList.add(order);
    }

    public void addCustomer(Customer customer, List<Customer> customerList) {
        customerList.add(customer);
    }
}
