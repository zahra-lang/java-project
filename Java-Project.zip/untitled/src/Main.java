import java.util.*;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static List<Customer> customers = new ArrayList<>();
    private static List<Employee> employees = new ArrayList<>();
    private static List<FoodItem> menu = new ArrayList<>();
    private static List<Order> orders = new ArrayList<>();
    // private static Gson gson = new Gson();

    // تعریف مدیر پیش فرض
    private static final Manager defaultManager = new Manager("احمد", "اذرنیا");

    public static void main(String[] args) {
        // بارگذاری داده‌ها
        customers = FileHandler.loadCustomers("customers.json");
        menu = FileHandler.loadMenu("menu.json");
        employees = FileHandler.loadEmployees("employees.json");
        orders = FileHandler.loadOrders("orders.json");

        println("به رستوران خوش آمدید");
        line();
        while (true) {
            print("لطفا گزینه مورد نظر را انتخاب کنید (1.مدیر/2.کارمند/3.مشتری/4.خروج):");

            String role = scanner.nextLine().trim().toLowerCase();
            switch (role) {
                case "1":
                    User userManager = loginManager();
                    if (userManager != null) {
                        println("خوش آمدید " + userManager.getUsername() + "!");
                        managerMenu((Manager) userManager);
                    } else {
                        println("مجدا تلاش کنید");
                    }
                    User userManager2 = loginManager();
                    if (userManager2 != null) {
                        println("خوش آمدید " + userManager2.getUsername() + "!");
                        managerMenu((Manager) userManager2);
                    } else {
                        println("نام کاربری یا رمز عبور مدیر اشتباه است.");
                    }
                    break;
                case "2":
                    User userEmployee = login();
                    if (userEmployee instanceof Employee) {
                        println("خوش آمدید " + userEmployee.getUsername() + "!");
                        employeeMenu((Employee) userEmployee);
                    } else {
                        println("مجدا تلاش کنید");
                    }
                    User userEmployee2 = login();
                    if (userEmployee2 != null) {
                        println("خوش آمدید " + userEmployee2.getUsername() + "!");
                        employeeMenu((Employee) userEmployee2);
                    } else {
                        println("نام کاربری یا رمز عبور اشتباه است.");
                    }
                    break;
                case "3":
                    User userCustomer = login();
                    if (userCustomer != null) {
                        println("خوش آمدید " + userCustomer.getUsername() + "!");
                        customerMenu((Customer) userCustomer);
                    } else {
                        println("مجدا تلاش کنید");
                    }
                    User userCustomer2 = login();
                    if (userCustomer2 != null) {
                        println("خوش آمدید " + userCustomer2.getUsername() + "!");
                        customerMenu((Customer) userCustomer2);
                    } else {
                        println("حساب کاربری مشتری یافت نشد.");
                        println("آیا می‌خواهید اکانت جدید ایجاد کنید؟ (بله/خیر)");
                        String createAccount = scanner.nextLine().trim().toLowerCase();
                        if (createAccount.equals("بله")) {
                            registerCustomer();
                        }
                    }
                    break;

                case "4":
                    println("خداحافظ!");
                    // ذخیره داده‌ها قبل از خروج
                    FileHandler.saveCustomers(customers, "customers.json");
                    FileHandler.saveMenu(menu, "menu.json");
                    FileHandler.saveEmployees(employees, "employees.json");
                    FileHandler.saveOrders(orders, "orders.json");
                    return;

                default:
                    println("لطفا فقط مدیر، کارمند، مشتری یا خروج وارد کنید.");
                    break;
            }

        }
    }

    private static User loginManager() {
        line();
        print("نام کاربری: ");
        String username = scanner.nextLine();
        print("رمز عبور: ");
        String password = scanner.nextLine();

        // بررسی مدیر پیش فرض
        if (defaultManager.getUsername().equals(username) && defaultManager.checkPassword(password)) {
            return defaultManager;
        }
        return null;
    }

    private static User login() {
        line();
        print("نام کاربری: ");
        String username = scanner.nextLine();
        print("رمز عبور: ");
        String password = scanner.nextLine();

        for (Employee e : employees) {
            if (e.getUsername().equals(username) && e.checkPassword(password)) {
                return e;
            }
        }
        for (Customer c : customers) {
            if (c.getUsername().equals(username) && c.checkPassword(password)) {
                return c;
            }
        }
        return null;
    }

    private static void registerCustomer() {
        line1();
        print("نام کاربری جدید: ");
        String username = scanner.nextLine();

        for (Customer c : customers) {
            if (c.getUsername().equals(username)) {
                println("این نام کاربری قبلا ثبت شده است.");
                return;
            }
        }
        print("رمز عبور: ");
        String password = scanner.nextLine();

        println("تلفن همراه:");
        String phone = scanner.nextLine();
        print("آیا می‌خواهید اشتراک بگیرید؟ (بله/خیر): ");
        String sub = scanner.nextLine().trim().toLowerCase();
        boolean hasSub = sub.equals("بله");

        Customer newCustomer = new Customer(username, password, hasSub, phone);
        customers.add(newCustomer);
        FileHandler.saveCustomers(customers, "customers.json");

        println("ثبت نام با موفقیت انجام شد.");
        if (hasSub) {
            println("کد تخفیف شما: " + newCustomer.getDiscountCode());
        }
        line();
    }

    private static void registerEmployee() {
        print("نام کاربری کارمند جدید: ");
        String username = scanner.nextLine();

        for (Employee e : employees) {
            if (e.getUsername().equals(username)) {
                println("این نام کاربری قبلا ثبت شده است.");
                return;
            }
        }

        print("رمز عبور کارمند جدید: ");
        String password = scanner.nextLine();

        Employee newEmployee = new Employee(username, password);
        employees.add(newEmployee);
        FileHandler.saveEmployees(employees, "employees.json");

        println("کارمند با موفقیت اضافه شد.");
        line1();
    }

    private static void managerMenu(Manager manager) {
        line();
        while (true) {
            println("منوی مدیر:");
            println("1. ویرایش منو (تغییر قیمت غذا)");
            println("2. مشاهده سفارشات");
            println("3. اضافه کردن مشتری");
            println("4. اضافه کردن کارمند");
            println("5. خروج");
            print("انتخاب: ");
            int choice = Integer.parseInt(scanner.nextLine());

            if (choice == 1) {
                println("============ منوی غذا ============");
                for (int i = 0; i < menu.size(); i++) {
                    println((i + 1) + ". " + menu.get(i));
                }

                manager.modifyMenu(menu, scanner);
                FileHandler.saveMenu(menu, "menu.json");

            } else if (choice == 2) {
                println("============ سفارشات ============");
                for (Order order : orders) {
                    println("نام مشتری: " + order.getCustomer().getUsername());
                    println("آیتم‌های سفارش: " + order.getItems());
                    println("مبلغ کل سفارش:" + order.calculateTotal());
                    line1();
                }

            } else if (choice == 3) {
                line1();
                print("نام کاربری مشتری جدید: ");
                String username = scanner.nextLine();
                print("رمز عبور مشتری جدید: ");
                String password = scanner.nextLine();
                print("تلفن همراه مشتری:");
                String phone = scanner.nextLine();
                Customer c = new Customer(username, password, false, phone);
                customers.add(c);
                FileHandler.saveCustomers(customers, "customers.json");
                println("مشتری اضافه شد.");
                line1();
            } else if (choice == 4) {
                line1();
                registerEmployee();
            } else if (choice == 5) {
                break;
            } else {
                println("گزینه نامعتبر!");
            }
        }
    }

    private static void employeeMenu(Employee employee) {
        line();
        while (true) {
            println("منوی کارمند:");
            println("1. مشاهده سفارشات");
            println("2. اضافه کردن مشتری");
            println("3. خروج");
            print("انتخاب: ");
            int choice = Integer.parseInt(scanner.nextLine());

            if (choice == 1) {
                println("============ سفارشات ============");
                for (Order order : orders) {
                    println("نام مشتری: " + order.getCustomer().getUsername());
                    println("آیتم‌های سفارش: " + order.getItems());
                    println("مبلغ کل سفارش:" + order.calculateTotal());
                    line1();
                }
            } else if (choice == 2) {
                line1();
                print("نام کاربری مشتری جدید: ");
                String username = scanner.nextLine();
                print("رمز عبور مشتری جدید: ");
                String password = scanner.nextLine();
                print("تلفن همراه مشتری :");
                String phone = scanner.nextLine();
                Customer c = new Customer(username, password, false, phone);
                customers.add(c);
                FileHandler.saveCustomers(customers, "customers.json");
                println("مشتری اضافه شد.");
                line1();
            } else if (choice == 3) {
                break;

            } else {
                println("گزینه نامعتبر!");
            }
        }
    }

    private static void customerMenu(Customer customer) {
        line();
        while (true) {
            println("منوی مشتری:");
            println("1. مشاهده منو غذا");
            println("2. مشاهده تاریخچه خرید");
            println("3. سبد خرید (اضافه کردن سفارش جدید)");
            println("4. خروج");
            print("انتخاب: ");
            int choice = Integer.parseInt(scanner.nextLine());

            if (choice == 1) {
                println("============ منوی غذا ============");
                for (int i = 0; i < menu.size(); i++) {
                    println((i + 1) + ". " + menu.get(i));
                }line1();
            } else if (choice == 2) {
                println("============ تاریخچه سفارشات شما ============");
                boolean hasOrders = false;
                for (Order order : orders) {
                    if (order.getCustomer().getUsername().equals(customer.getUsername())) {
                        //  System.out.println("نام مشتری: " + customer.getUsername());
                        println("آیتم‌های سفارش: " + order.getItems());
                        println("مبلغ کل سفارش:" + order.calculateTotal());
                        hasOrders = true;
                        line1();
                    }
                }
                if (!hasOrders) {
                    println("هیچ سفارشی ثبت نشده است.");
                    line1();
                }
            } else if (choice == 3) {
                List<FoodItem> selectedItems = new ArrayList<>();
                while (true) {
                    println("============ منوی غذا ============");
                    for (int i = 0; i < menu.size(); i++) {
                        println((i + 1) + ". " + menu.get(i));
                    }
                    line1();
                    println("0. ثبت سفارش و خروج");
                    print("شماره غذا برای اضافه کردن به سبد (یا 0 برای ثبت): ");
                    int itemChoice = Integer.parseInt(scanner.nextLine());

                    if (itemChoice == 0) {
                        if (selectedItems.isEmpty()) {
                            println("سبد خرید خالی است!");
                            line1();
                            break;
                        } else {
                            // محاسبه قیمت کل
                            double totalPrice = 0;
                            for (FoodItem item : selectedItems) {
                                totalPrice += item.getPrice();
                            }
                            println("قیمت کل سفارش: " + totalPrice);
                            print("اگر کد تخفیف دارید وارد کنید (یا Enter برای رد کردن):");
                            String inputDiscountCode = scanner.nextLine().trim();

                            double finalPrice = totalPrice;
                            if (!inputDiscountCode.isEmpty()) {
                                if (inputDiscountCode.equalsIgnoreCase(customer.getDiscountCode())) {
                                    double discountAmount = totalPrice * 0.10;
                                    finalPrice = totalPrice - discountAmount;
                                    println("کد تخفیف معتبر است !مبلغ تخفیف:" + discountAmount);
                                    //System.out.printf("کد تخفیف معتبر است! مبلغ تخفیف: %.2f\n", discountAmount);
                                } else {
                                    println("کد تخفیف نامعتبر است.");
                                }
                            } else {
                                println("کد تخفیفی وارد نشد.");
                            }
                            println("قیمت نهایی بعد از تخفیف: " + finalPrice);

                            print("آیا می‌خواهید پرداخت را انجام دهید؟ (بله/خیر): ");
                            String payConfirm = scanner.nextLine().trim().toLowerCase();

                            if (payConfirm.equals("بله")) {
                                print("آدرس تحویل: ");
                                String address = scanner.nextLine();

                                Order newOrder = new Order(customer, new ArrayList<>(selectedItems), true, address);
                                orders.add(newOrder);
                                FileHandler.saveOrders(orders, "orders.json");
                                println("سفارش شما ثبت شد. با تشکر!");
                                line1();
                                break;
                            } else {
                                println("پرداخت لغو شد، به منوی سفارش بازگشتید.");
                                line1();
                                break;
                            }
                        }
                    } else if (itemChoice > 0 && itemChoice <= menu.size()) {
                        selectedItems.add(menu.get(itemChoice - 1));
                        println("به سبد اضافه شد: " + menu.get(itemChoice - 1).getName());
                    } else {
                        println("گزینه نامعتبر!");
                    }
                }
            } else if (choice == 4) {
                break;
            } else {
                println("گزینه نامعتبر!");
            }
        }
    }

    public static void println(String text) {
        int width = 150;
        System.out.println(String.format("%" + (width / 2 + text.length() / 2) + "s", text));

    }

    public static void print(String text) {
        int width = 150;
        System.out.print(String.format("%" + (width / 2 + text.length() / 2) + "s", text));

    }
    public static void line() {
        String text = "                  ==================================================================================================================";
        System.out.println(text);
    }
    public static void line1(){
        String text="                  --------------------------------------------------------------------------------------------------------------------";
        System.out.println(text);
    }

}


