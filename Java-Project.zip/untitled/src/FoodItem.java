public class FoodItem {
    static String getName;
    public FoodItem getFoodItem;
    String id;
    String name;
    double price;
    String description;
    String category;
    boolean available;


    public FoodItem(String name, double price , String description, String category, boolean available, String id) {
        this.name = name;
        this.price = price;
        this.description = description;
        this.category = category;
        this.available = available;
        this.id = id;
    }


    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getDescription() {
        return description;
    }
    public  void  setDescription(String description) {
        this.description = description;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return name + ": " + price + " تومان";
    }

}

