public class Customer extends User {
    boolean hasSubscription;
    String discountCode;
    String phone;

    public Customer(String username, String password, boolean hasSubscription,String phone) {
        super(username, password);
        this.hasSubscription = hasSubscription;
        if (hasSubscription) {
            this.discountCode = generateDiscountCode();
        } else {
            this.discountCode = null;
        }
        this.phone = phone;
    }

    private String generateDiscountCode() {
        return "SUB10";
    }

    public boolean hasSubscription() {
        return hasSubscription;
    }

    public String getDiscountCode() {
        return discountCode;
    }

}

